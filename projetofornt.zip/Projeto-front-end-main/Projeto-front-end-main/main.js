const botaoTema = document.getElementById("themeToggle");
const icon = document.querySelector(".icon");

botaoTema.addEventListener("click", () => {

    document.body.classList.toggle("light-theme");

    if(document.body.classList.contains("light-theme")){
        icon.textContent = "🌙";
    }else{
        icon.textContent = "☀";
    }
    if(localStorage.getItem("theme") === "claro"){
        document.body.classList.add("light-theme");
    }
});


